// OpenGL_Template.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <cstdlib>
#include <vector>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

//Image handling
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

//GLM header includes
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <learnOpenGL/camera.h> //INLCUDE CAMERA CLASS, MODIFIED FROM TUTORIAL SOLUTION (CREATIVE COMMONS LICENSE)

using namespace std;



//Shader program macro (makes declaring shader programs MUCH tidier???)
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif // !GLSL



//Unnamed namespace, which is apparently a thing
namespace
{
    //Window title, width, and height
    const char* const WINDOW_TITLE = "Module_Six_Milestone";
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 600;

    //Struct for OpenGL mesh data
    struct GLMesh
    {
        GLuint vao;         //Vertex array object
        GLuint vbo;         //SINGLE vertex buffer object
        GLuint nVertices;   //Number of vertices in the mesh
    };

    //Main GLFW window
    GLFWwindow* gWindow = nullptr;

    //Mesh data
    GLMesh gCubeLightMesh;
    GLMesh gBackgroundPlaneMesh;
    GLMesh gPlaneMesh;
    GLMesh gBatteryBody;
    GLMesh gBatteryPostL;
    GLMesh gBatteryPostR;
    GLMesh gOilFilterMesh;
    GLMesh gCardDeckMesh;
    GLMesh gRubberBandMesh; //TEMPORARILY IS CYLINDER
    GLMesh gPyramidMesh;

    //Texture data
    GLuint gBackgroundTexID;
    GLuint gBatteryBodyTexID;
    GLuint gBatteryPostTexID;
    GLuint gPlanePaperTexID;
    GLuint gOilFilterTexID;
    GLuint gCardDeckTexID;
    GLuint gPyramidTexID;

    //Shader programs (int as ID)
    GLuint gProgramID;      //Regular object(s)
    GLuint gLightProgramID; //Light source(s)

    //Camera and mouse tracking variables
    Camera gCamera(glm::vec3(0.0f, 3.0f, 10.0f));   //Initially move back considerably
    float gLastX = WINDOW_WIDTH / 2.0f;             //Initially center mouse x position
    float gLastY = WINDOW_HEIGHT / 2.0f;            //Initially center mouse y position
    bool gFirstMouse = true;                        //Tracks whether this is the first mouse movement caught by the application

    //Frame time variables
    float gDeltaTime = 0.0f;    //Change in time between last frame and this frame
    float gLastFrame = 0.0f;    //Time of last frame

    //Booleans to handle perspective or orthographic projection.
    bool usePerspective = true;
    bool pKeyPressed = false;   //Used to allow operation ONLY when key has just been released.



    //STORING DATA IN CONTAINERS LIKE THESE IS THE BEST AND MOST MODULAR OPTION
    //Light color, position, and scale (both lights)
    glm::vec3 gPointLightColors[] = {
        glm::vec3(1.0f, 1.0f, 1.0f),
        glm::vec3(0.5f, 0.5f, 0.25f)
    };
    glm::vec3 gPointLightPositions[] = {
        glm::vec3(-4.5f, 4.0f, 5.0f),
        glm::vec3(2.0f, 1.25f, -3.0f)
    };
    glm::vec3 gLightScale(0.3f);
}



//FUNCTION PROTOTYPES
bool UInitialize(GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
//Callbacks for mouse input
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);

void UGenerateMeshes();
void UDestroyAllMeshes();
void UCreateMesh(GLfloat vertices[], int numVertices, GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool ULoadTextures();
void UDestroyAllTextures();
bool UCreateTexture(const char* filename, GLuint& textureID);
void UDestroyTexture(GLuint textureID);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSrouce, GLuint& programID);
void UDestroyShaderProgram(GLuint programID);

//BELOW FUNCTIONS SHOULD PROBABLY BE MOVED TO A SEPARATE FILE/MODULE
void UCreatePlaneMesh(GLMesh& mesh);
void UCreateCubeMesh(GLMesh& mesh);
void UCreatePyramidMesh(GLMesh& mesh);
void UCreateCylinderMesh(float r, float h, float res, GLMesh& mesh);
glm::mat4 UGenerateModelMatrix(glm::vec3 scale, glm::vec3 rotation, glm::vec3 translate);



//Vertex shader program source code (now using nice macro)
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;  //Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal;    //Normal data from Vertex Attrib Pointer 1
    layout(location = 2) in vec2 texCoordinate; //Texture coordinate data from Vertex Attrib Pointer 2

    out vec3 vertexFragPosition;            //Variable to transfer vertex position to the fragment shader
    out vec3 vertexNormal;                  //Variable to transfer normal data to the fragment shader
    out vec2 vertexTexCoordinate;           //Variable to transfer texture coordinate data to the fragment shader

    //Global variables for transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); //Transforms vertices to clip coordinates (R to L)
        vertexFragPosition = vec3(model * vec4(position, 1.0f));        //Gets fragment position in world space

        vertexNormal = mat3(transpose(inverse(model))) * normal;        //Get normal vectors in world space (ignore view and projection)
        vertexTexCoordinate = texCoordinate;            //References incoming texture coordinate data
    }
);

//Fragment shader program source code (now using nice macro)
const GLchar* fragmentShaderSource = GLSL(440,
    in vec3 vertexFragPosition;             //Holds incoming fragment position data from vertex shader
    in vec3 vertexNormal;                   //Holds incoming normal data from vertex shader
    in vec2 vertexTexCoordinate;            //Holds incoming texture coordinate data from vertex shader

    out vec4 fragmentColor;                 //Final produced vertex color

    //Uniforms for light color, light position, camera view/position, and texture data
    uniform vec3 lightColor[2];
    uniform vec3 lightPos[2];
    uniform vec3 viewPosition;
    uniform sampler2D uTexture;             //Single sampler uniform, associated with the base texture

    void main()
    {
        //Phong lighting model calculations for ambient, diffuse, and specular lighting.

        //Declare empty temporary variable to hold incremental lighting data.
        vec3 phongOutput = vec3(0.0f);

        //LOOP THROUGH ALL LIGHTS HERE
        for (int i = 0; i < 2; i++)
        {
            //Ambient
            float ambientStrength = 0.2f;
            vec3 ambient = ambientStrength * lightColor[i];

            //Diffuse
            vec3 norm = normalize(vertexNormal);    //Actually normalize normal vectors
            vec3 lightDirection = normalize(lightPos[i] - vertexFragPosition);  //Get light direction from distance between light and fragment
            float impact = max(dot(norm, lightDirection), 0.0); //Calculate diffuse impact based on dot product of normal and light direction
            vec3 diffuse = impact * lightColor[i];

            //Specular
            float specularIntensity = 0.8f;
            float highlightSize = 32.0f;
            vec3 viewDir = normalize(viewPosition - vertexFragPosition);    //Calculate view direction
            vec3 reflectDir = reflect(-lightDirection, norm);   //Calculate reflection vector of object surface
            float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0f), highlightSize);  //Actual specular component
            vec3 specular = specularIntensity * specularComponent * lightColor[i];

            //Add to temporary variable.
            phongOutput += (ambient + diffuse + specular);
        }

        //Get texture color at this location from texture data, then calculate Phong result.
        vec4 textureColor = texture(uTexture, vertexTexCoordinate);
        vec3 phong = phongOutput * textureColor.xyz;

        //FINALLY, send lighting results to the GPU.
        fragmentColor = vec4(phong, 1.0);
    }
);

//Light vertex shader source code.
const GLchar* lightVertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position;  //Position data

    //Global variables for transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); //Transforms vertices to clip coordinates (R to L)
    }
);

//Light fragment shader source code
const GLchar* lightFragmentShaderSource = GLSL(440,

    out vec4 fragmentColor;         //Final produced color

    void main()
    {
        fragmentColor = vec4(1.0f); //Set color to pure white
    }
);



//Helper function to flip an image vertically because of opposite Y axes.
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    //Loop through each row of pixels.
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        //Nested loop through each individual pixel in each row.
        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}



//Main entry point to program. Contains execution loop.
int main()
{
    //If window fails to initialize, exit as failure.
    if (!UInitialize(&gWindow))
    {
        return EXIT_FAILURE;
    }

    //Create ALL meshes.
    UGenerateMeshes();

    //Create ALL textures.
    if (!ULoadTextures())
    {
        return EXIT_FAILURE;    //If there is an error, it will be logged within ULoadTextures() but must exit here.
    }

    //If shader program fails to create, exit as failure.
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramID))
    {
        std::cout << "First bad" << std::endl;
        return EXIT_FAILURE;
    }
    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramID))
    {
        std::cout << "Second bad" << std::endl;
        return EXIT_FAILURE;
    }

    //Set window background color to black, will full opacity.
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    //MAIN RENDER LOOP
    while (!glfwWindowShouldClose(gWindow))
    {
        //First, calculate frame time at the start of every frame.
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame;
        gLastFrame = currentFrame;

        //Process input.
        UProcessInput(gWindow);

        //Perform all rendering operations this frame (including swapping buffers, etc.).
        URender();

        //Process all pending events before looping again.
        glfwPollEvents();
    }

    //Once loop ends, release/destroy mesh, shader program, and all textures.
    UDestroyAllMeshes();
    UDestroyShaderProgram(gProgramID);
    UDestroyShaderProgram(gLightProgramID);
    UDestroyAllTextures();

    //Finally, exit program as success.
    exit(EXIT_SUCCESS);
}



//Initialize GLFW, GLEW, and create window.
bool UInitialize(GLFWwindow** window)
{
    //Init GLFW and set configurations (version 4.4).
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    //Assuming this is for apple devices???
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    //Window creation. Must set current context and buffer size callback (UResizeWindow function).
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        //If creation fails, log error and return false (failure).
        std::cout << "Failed to create GLFW window." << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);

    //Set mouse callbacks.
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    //Set cursor capture mode.
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    //GLEW initialization.
    glewExperimental = GL_TRUE;     //Required if using GLEW version 1.13 or earlier?
    GLenum GlewInitResult = glewInit();
    if (GLEW_OK != GlewInitResult)
    {
        //If initialization fails, log error and return false (failure).
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    //Finally, display OpenGL version in console, then return true.
    std::cout << "INFO: OpenGL version: " << glGetString(GL_VERSION) << std::endl;
    return true;
}



//Process any input, which queries GLFW whether relevant keys were pressed/released this frame and does corresponding operations.
void UProcessInput(GLFWwindow* window)
{
    //If the escape key is pressed, will exit application next frame.
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
    {
        glfwSetWindowShouldClose(window, true);
    }

    //Check for WASD and QE input, then call necessary Camera functions accordingly.
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    }
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
    {
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);
    }

    //Handle P key press, which swaps between perspective and orthographic projection.
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
    {
        //If P key pressed, set variable used when key is released.
        pKeyPressed = true;
    }
    else
    {
        //If p key was pressed last frame and no longer is, flip-flop between perspective and orthographic projection.
        if (pKeyPressed)
        {
            usePerspective = !usePerspective;
        }
        pKeyPressed = false;    //Always reset to false here.
    }
}

//Callback function that executes whenever the window is resized.
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

//Callback function for mouse position (changes camera orientation).
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    //First, if this is the first time the mouse has been captured, manually set x and y position to avoid camera snap.
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    //Calculate offset to rotate camera by from previous mouse vs current mouse.
    float xOffset = xpos - gLastX;
    float yOffset = gLastY - ypos;  //Reversed

    //Set variables for last x and y coordinates, for use next call.
    gLastX = xpos;
    gLastY = ypos;

    //Finally, actually process mouse movement (changes camera orientation).
    gCamera.ProcessMouseMovement(xOffset, yOffset);
}

//Callback function to handle mouse scroll operations (changes camera movement speed).
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);    //Only needs y offset because is simple mouse scroll wheel (no x-axis).
}

//Callback function to handle mouse button click (CURRENTLY UNUSED).
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    //nada
}



//Performs all per-frame rendering operations.
void URender()
{
    //Enable z-depth-testing function (required every render iteration???).
    glEnable(GL_DEPTH_TEST);

    //Set background clear color, then clear color buffer AND z-depth buffer.
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    //Get the Camera object's view matrix.
    glm::mat4 view = gCamera.GetViewMatrix();

    //Determine which projection matrix type to use.
    glm::mat4 projection;
    if (usePerspective)
    {
        //Create perspective projection matrix from Camera object's Zoom value.
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
    }
    else
    {
        //Create orthographic projection matrix (I'm a bit fuzzy on left/right and bottom/top scales here).
        projection = glm::ortho(-((GLfloat)WINDOW_WIDTH / 100.0f), (GLfloat)WINDOW_WIDTH / 100.0f,
            -((GLfloat)WINDOW_HEIGHT / 100.0f), (GLfloat)WINDOW_HEIGHT / 100.0f, -1000.0f, 1000.0f);
    }
    


    //DRAW REGULAR OBJECTS
    //Set the shader program to be used, which has already been initialized and is ready.
    glUseProgram(gProgramID);

    //Retrieve and pass transformation matrices (view and projection, NOT model yet) to the shader program.
    GLint modelLoc = glGetUniformLocation(gProgramID, "model");
    GLint viewLoc = glGetUniformLocation(gProgramID, "view");
    GLint projLoc = glGetUniformLocation(gProgramID, "projection");
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    //Reference matrix uniforms from the MAIN shader program (data corresponding to BOTH lights).
    GLint lightColor1Loc = glGetUniformLocation(gProgramID, "lightColor[0]");
    GLint lightPosition1Loc = glGetUniformLocation(gProgramID, "lightPos[0]");
    GLint lightColor2Loc = glGetUniformLocation(gProgramID, "lightColor[1]");
    GLint lightPosition2Loc = glGetUniformLocation(gProgramID, "lightPos[1]");
    GLint viewPositionLoc = glGetUniformLocation(gProgramID, "viewPosition");

    //Pass color, light, and view (camera) data to the MAIN shader program (again, BOTH lights).
    glUniform3f(lightColor1Loc, gPointLightColors[0].r, gPointLightColors[0].g, gPointLightColors[0].b);
    glUniform3f(lightPosition1Loc, gPointLightPositions[0].x, gPointLightPositions[0].y, gPointLightPositions[0].z);
    glUniform3f(lightColor2Loc, gPointLightColors[1].r, gPointLightColors[1].g, gPointLightColors[1].b);
    glUniform3f(lightPosition2Loc, gPointLightPositions[1].x, gPointLightPositions[1].y, gPointLightPositions[1].z);
    const glm::vec3 cameraPosition = gCamera.Position;
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);



    //Before drawing, bind texture to the corresponding texture unit (only 0 at the moment).
    glActiveTexture(GL_TEXTURE0);

    //BACKGROUND PLANE
    glm::mat4 model = UGenerateModelMatrix(glm::vec3(25.0f, 1.0f, 25.0f), glm::vec3(0.0f), glm::vec3(0.0f, -0.05f, 0.0f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    //Activate the VBOs contained within the mesh's VAO (already initialized and ready).
    glBindTexture(GL_TEXTURE_2D, gBackgroundTexID); //ONLY THIS NEEDS TO BE REDONE FOR EACH ITEM
    glBindVertexArray(gBackgroundPlaneMesh.vao);
    //Draw arrays (not indices because textures and normals).
    glDrawArrays(GL_TRIANGLES, 0, gBackgroundPlaneMesh.nVertices);

    //YELLOW PAPER PLANE
    model = UGenerateModelMatrix(glm::vec3(8.4f, 1.0f, 7.0f), glm::vec3(0.0f), glm::vec3(0.0f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gPlanePaperTexID);
    glBindVertexArray(gPlaneMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gPlaneMesh.nVertices);

    //BATTERY BODY
    model = UGenerateModelMatrix(glm::vec3(0.6f, 0.9f, 0.4f), glm::vec3(0.0f, -25.0f, 0.0f), glm::vec3(-1.5f, 0.45f, 1.7f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gBatteryBodyTexID);
    glBindVertexArray(gBatteryBody.vao);
    glDrawArrays(GL_TRIANGLES, 0, gBatteryBody.nVertices);

    //BATTERY POST LEFT
    model = UGenerateModelMatrix(glm::vec3(0.4f), glm::vec3(0.0f, -25.0f, 0.0f), glm::vec3(-1.63f, 0.93f, 1.64f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gBatteryPostTexID);    //BATTERY POSTS USE SIMPLE METALLIC TEXTURE
    glBindVertexArray(gBatteryPostL.vao);
    glDrawArrays(GL_TRIANGLES, 0, gBatteryPostL.nVertices);

    //BATTERY POST RIGHT
    model = UGenerateModelMatrix(glm::vec3(0.4f), glm::vec3(0.0f, -25.0f, 0.0f), glm::vec3(-1.38f, 0.90f, 1.76f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindVertexArray(gBatteryPostR.vao);
    glDrawArrays(GL_TRIANGLES, 0, gBatteryPostR.nVertices);

    //OIL FILTER CYLINDER
    model = UGenerateModelMatrix(glm::vec3(1.0f), glm::vec3(0.0f, 0.0f, 0.0f), glm::vec3(-2.40f, 1.30f, -1.30f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gOilFilterTexID);
    glBindVertexArray(gOilFilterMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gOilFilterMesh.nVertices);

    //CARD DECK CUBE
    model = UGenerateModelMatrix(glm::vec3(1.5f, 2.3f, 0.36f), glm::vec3(-90.0f, 0.0f, -30.0f), glm::vec3(0.30f, 0.18f, -0.70f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gCardDeckTexID);
    glBindVertexArray(gCardDeckMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gCardDeckMesh.nVertices);

    //RUBBER BAND TORUS (IS TEMPORARILY CYLINDER)
    model = UGenerateModelMatrix(glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.0f, -30.0f, -17.0f), glm::vec3(1.35f, 0.38f, -0.05f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gOilFilterTexID);
    glBindVertexArray(gRubberBandMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gRubberBandMesh.nVertices);

    //PYRAMID (SOMEWHAT BS SOLUTION TO NOT BEING ABLE TO CREATE A TORUS)
    model = UGenerateModelMatrix(glm::vec3(1.0f, 1.0f, 1.0f), glm::vec3(0.0f, 30.0f, 0.0f), glm::vec3(2.50f, 0.50f, 2.00f));
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindTexture(GL_TEXTURE_2D, gPyramidTexID);
    glBindVertexArray(gPyramidMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gPyramidMesh.nVertices);



    //DRAW MAIN LIGHT
    //Set the shader program to be used, which has already been initialized and is ready.
    glUseProgram(gLightProgramID);

    //Generate simple model matrix for the FIRST light object.
    model = glm::translate(gPointLightPositions[0]) * glm::scale(gLightScale);
    //Retrieve and pass transformation matrices (model, view, projection) to the shader program.
    modelLoc = glGetUniformLocation(gLightProgramID, "model");
    viewLoc = glGetUniformLocation(gLightProgramID, "view");
    projLoc = glGetUniformLocation(gLightProgramID, "projection");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
    //Activate the VBOs contained within the mesh's VAO (already initialized and ready).
    glBindVertexArray(gCubeLightMesh.vao);
    //Draw arrays (not indices because textures and normals).
    glDrawArrays(GL_TRIANGLES, 0, gCubeLightMesh.nVertices);


    //DRAW SECONDARY DARKER LIGHT
    //Generate simple model matrix for the SECOND light object.
    model = glm::translate(gPointLightPositions[1]) * glm::scale(gLightScale);
    //Update model matrix in the shader program (already have location, and view/projection has not changed).
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glBindVertexArray(gCubeLightMesh.vao);
    glDrawArrays(GL_TRIANGLES, 0, gCubeLightMesh.nVertices);



    //Deactivate the VAO and the VBOs contained within by binding a nonexistent VAO.
    glBindVertexArray(0);

    //Finally, swap buffers to display the newly rendered frame.
    glfwSwapBuffers(gWindow);
}


//Handles generation of all mesh data (vertex and color), then calls UCreateMesh() to create the actual objects.
void UGenerateMeshes()
{
    //Create cube light model.
    UCreateCubeMesh(gCubeLightMesh);

    //Planes under objects.
    UCreatePlaneMesh(gBackgroundPlaneMesh);
    UCreatePlaneMesh(gPlaneMesh);

    //Battery meshes.
    UCreateCubeMesh(gBatteryBody);
    UCreateCylinderMesh(0.2f, 0.2f, 12, gBatteryPostL);
    UCreateCylinderMesh(0.25f, 0.5f, 6, gBatteryPostR);

    //Oil filter mesh.
    UCreateCylinderMesh(0.9f, 2.6f, 12.0f, gOilFilterMesh);

    //Card deck mesh.
    UCreateCubeMesh(gCardDeckMesh);

    //Rubber band mesh (TEMPORARILY IS CYLINDER).
    UCreateCylinderMesh(0.8f, 0.3f, 24.0f, gRubberBandMesh);

    //Pyramid mesh
    UCreatePyramidMesh(gPyramidMesh);
}

//Handles destroying all mesh data.
void UDestroyAllMeshes()
{
    //Individually destroy each mesh by passing in the objects by reference.
    UDestroyMesh(gCubeLightMesh);
    UDestroyMesh(gBackgroundPlaneMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gBatteryBody);
    UDestroyMesh(gBatteryPostL);
    UDestroyMesh(gBatteryPostR);
    UDestroyMesh(gOilFilterMesh);
    UDestroyMesh(gCardDeckMesh);
    UDestroyMesh(gRubberBandMesh);
    UDestroyMesh(gPyramidMesh);
}

//Create mesh from vertex and color arrays, then assign to a by-reference GLMesh object.
void UCreateMesh(GLfloat vertices[], int numVertices, GLMesh& mesh)
{
    //Store number of coordinates per vertex, normal, and texture coordinate for use later.
    const GLuint floatsPerVertex = 3;   //3 coordinates per vertex (xyz)
    const GLuint floatsPerNormal = 3;   //3 values per normal (xyz)
    const GLuint floatsPerUV = 2;       //2 values per texture coordinate (uv)

    //Generate and bind a new VAO to the passed-in GLMesh object.
    glGenVertexArrays(1, &mesh.vao);
    glBindVertexArray(mesh.vao);

    //Create SINGLE buffer for vertex data, then activate and send vertex/coordinate data to the GPU.
    glGenBuffers(1, &mesh.vbo);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo);
    glBufferData(GL_ARRAY_BUFFER, numVertices, vertices, GL_STATIC_DRAW);

    //Determine number of vertices and assign to mesh variable.
    mesh.nVertices = numVertices / (sizeof(vertices[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    //Calculate and store strides between vertex coordinates, which is 8 (xyzxyzuv).
    GLint stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);   //Each value is a float, hence multiplication

    //Finally, create vertex attribute pointers for both the coordinates and the colors.
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);   //First, coords
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (char*)(sizeof(float) * floatsPerVertex));
    glEnableVertexAttribArray(1);   //Second, normals
    glVertexAttribPointer(2, floatsPerUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);   //Third, UVs
}

//Destroys/releases the passed-by-reference GLMesh object.
void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao);
    glDeleteBuffers(1, &mesh.vbo);      //ONE buffer was created and must be destroyed.
}



//Handles loading all textures sequentially.
bool ULoadTextures()
{
    //BLUE BACKGROUND TEXTURE
    const char* texFilename = "blue_background.png";
    if (!UCreateTexture(texFilename, gBackgroundTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //BATTERY BODY TEXTURE
    texFilename = "Battery_Body.png";
    if (!UCreateTexture(texFilename, gBatteryBodyTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //BATTERY POST TEXTURE
    texFilename = "metal_background.png";
    if (!UCreateTexture(texFilename, gBatteryPostTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //PLANE PAPER TEXTURE
    texFilename = "brown_paper_background.jpg";
    if (!UCreateTexture(texFilename, gPlanePaperTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //OIL FILTER BLUE TEXTURE
    texFilename = "oil_filter_blue.png";
    if (!UCreateTexture(texFilename, gOilFilterTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //CARD DECK RED TEXTURE (TEMPORARY)
    texFilename = "temp_card_red.png";
    if (!UCreateTexture(texFilename, gCardDeckTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //PYRAMID BRICK TEXTURE (TEMPORARY)
    texFilename = "Brick_Texture.jpg";
    if (!UCreateTexture(texFilename, gPyramidTexID))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return false;
    }

    //Set textures as texture unit 0.
    glUseProgram(gProgramID);
    glUniform1i(glGetUniformLocation(gProgramID, "uTextureBase"), 0);
}

//Handles destroying all textures.
void UDestroyAllTextures()
{
    //Individually destroy each texture by passing each texture ID into the function.
    UDestroyTexture(gBatteryBodyTexID);
    UDestroyTexture(gBatteryPostTexID);
    UDestroyTexture(gPlanePaperTexID);
    UDestroyTexture(gBackgroundTexID);
    UDestroyTexture(gOilFilterTexID);
    UDestroyTexture(gCardDeckTexID);
    UDestroyTexture(gPyramidTexID);
}

//Creates and loads a texture into the passed-in texture ID.
bool UCreateTexture(const char* filename, GLuint& textureID)
{
    //Get image data and assign width, height, and channels to local variables.
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        //First, flip image because OpenGL and image formats have reversed Y directions.
        flipImageVertically(image, width, height, channels);

        //Generate and bind textures.
        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        //Set texture wrapping parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

        //Set texture filtering parameters.
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        //Call function based on number of channels, RGB or RBGA.
        if (channels == 3)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        else if (channels == 4)
        {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        //Generate mipmaps for the generated texture.
        glGenerateMipmap(GL_TEXTURE_2D);

        //Finally, free and unbind the texture then return true (success).
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return true;
    }

    //Only reaches here if there is an error loading the image.
    return false;
}

//Destroys the passed-in texture to free memory.
void UDestroyTexture(GLuint textureID)
{
    //Apparently this destroys the texture?
    glGenTextures(1, &textureID);
}



//Create necessary shader program(s) and assign to by-reference program ID.
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programID)
{
    //Used for compilation/linking error logging.
    int success = 0;
    char infoLog[512];

    //Create shader program object, then create vertex and fragment shader objects.
    programID = glCreateProgram();
    GLuint vertexShaderID = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderID = glCreateShader(GL_FRAGMENT_SHADER);

    //Retrieve shader sources for both shader objects.
    glShaderSource(vertexShaderID, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderID, 1, &fragShaderSource, NULL);

    //Compile the vertex shader, then check for compilation errors.
    glCompileShader(vertexShaderID);
    glGetShaderiv(vertexShaderID, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        //If failed to compile vertex shader, log error then return false (failure).
        glGetShaderInfoLog(vertexShaderID, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;
        return false;
    }

    //Compile the fragment shader, then check for compilation errors.
    glCompileShader(fragmentShaderID);
    glGetShaderiv(fragmentShaderID, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        //If failed to compile fragment shader, log error then return false (failure).
        glGetShaderInfoLog(fragmentShaderID, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;
        return false;
    }

    //Attach now SUCCESSFULLY compiled shaders to shader program.
    glAttachShader(programID, vertexShaderID);
    glAttachShader(programID, fragmentShaderID);

    //Link the shader program, then check for compilation errors.
    glLinkProgram(programID);
    glGetProgramiv(programID, GL_LINK_STATUS, &success);
    if (!success)
    {
        //If failed to link program, log error then return false (failure).
        glGetProgramInfoLog(programID, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;
        return false;
    }

    //Finally, use the generated shader program and return true (success).
    glUseProgram(programID);
    return true;
}

//Destroys/releases the passed-by-ID shader program.
void UDestroyShaderProgram(GLuint programID)
{
    glDeleteProgram(programID);
}



//Create xz plane mesh of predefined width 1 and depth 1 (horizontal plane), and assign to GLMesh object.
void UCreatePlaneMesh(GLMesh& mesh)
{
    //First, define Normalized Device Coordinates (xyz), normals (xyz), and texture coordinates (uv) for triangle vertices.
    GLfloat vertices[] =
    {
        //THEORETICALLY, THESE NORMALS DO NOT HAVE TO BE NORMALIZED

        //The one face
        -0.5f, 0.0f, 0.5f,   0.0f, 1.0f, 0.0f,       0.0f, 0.0f,   //Front-left
        0.5f, 0.0f, 0.5f,    0.0f, 1.0f, 0.0f,       1.0f, 0.0f,   //Front-right
        0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,       1.0f, 1.0f,   //Back-right
        -0.5f, 0.0f, 0.5f,   0.0f, 1.0f, 0.0f,       0.0f, 0.0f,   //Front-left
        -0.5f, 0.0f, -0.5f,  0.0f, 1.0f, 0.0f,       0.0f, 1.0f,   //Back-left
        0.5f, 0.0f, -0.5f,   0.0f, 1.0f, 0.0f,       1.0f, 1.0f    //Back-right
    };

    //Actually create the mesh object from the defined vertices and assign to GLMesh object.
    UCreateMesh(vertices, sizeof(vertices), mesh);  //NOTE: Must pass in size of array.
}

//Create cube mesh of predefined width 1, height 1, and depth 1, and assign to the passed-in GLMesh object.
void UCreateCubeMesh(GLMesh& mesh)
{
    //First, define Normalized Device Coordinates (xyz), normals (xyz), and texture coordinates (uv) for triangle vertices.
    GLfloat vertices[] =
    {
        //THEORETICALLY, THESE NORMALS DO NOT HAVE TO BE NORMALIZED

        //Bottom face
        -0.5f, -0.5f, 0.5f,    0.0f, -1.0f, 0.0f,      0.0f, 0.0f,  //Front-left
        0.5f, -0.5f, 0.5f,     0.0f, -1.0f, 0.0f,      0.64f, 0.0f,  //Front-right
        0.5f, -0.5f, -0.5f,    0.0f, -1.0f, 0.0f,      0.64f, 0.0f,  //Back-right
        -0.5f, -0.5f, 0.5f,    0.0f, -1.0f, 0.0f,      0.0f, 0.0f,  //Front-left
        -0.5f, -0.5f, -0.5f,   0.0f, -1.0f, 0.0f,      0.0f, 0.0f,  //Back-left
        0.5f, -0.5f, -0.5f,    0.0f, -1.0f, 0.0f,      0.64f, 0.0f,  //Back-right

        //Top face
        -0.5f, 0.5f, 0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  //Front-left
        0.5f, 0.5f, 0.5f,      0.0f, 1.0f, 0.0f,       0.64f, 1.0f,  //Front-right
        0.5f, 0.5f, -0.5f,     0.0f, 1.0f, 0.0f,       0.64f, 1.0f,  //Back-right
        -0.5f, 0.5f, 0.5f,     0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  //Front-left
        -0.5f, 0.5f, -0.5f,    0.0f, 1.0f, 0.0f,       0.0f, 1.0f,  //Back-left
        0.5f, 0.5f, -0.5f,     0.0f, 1.0f, 0.0f,       0.64f, 1.0f,  //Back-right

        //Front face
        -0.5f, 0.5f, 0.5f,     0.0f, 0.0f, 1.0f,       0.0f, 1.0f,  //Top-left
        0.5f, 0.5f, 0.5f,      0.0f, 0.0f, 1.0f,       0.64f, 1.0f,  //Top-right
        0.5f, -0.5f, 0.5f,     0.0f, 0.0f, 1.0f,       0.64f, 0.0f,  //Bottom-right
        -0.5f, 0.5f, 0.5f,     0.0f, 0.0f, 1.0f,       0.0f, 1.0f,  //Top-left
        -0.5f, -0.5f, 0.5f,    0.0f, 0.0f, 1.0f,       0.0f, 0.0f,  //Bottom-left
        0.5f, -0.5f, 0.5f,     0.0f, 0.0f, 1.0f,       0.64f, 0.0f,  //Bottom-right

        //Right face
        0.5f, 0.5f, 0.5f,      1.0f, 0.0f, 0.0f,       0.64f, 1.0f,  //Top-left
        0.5f, 0.5f, -0.5f,     1.0f, 0.0f, 0.0f,       1.0f, 1.0f,  //Top-right
        0.5f, -0.5f, -0.5f,    1.0f, 0.0f, 0.0f,       1.0f, 0.0f,  //Bottom-right
        0.5f, 0.5f, 0.5f,      1.0f, 0.0f, 0.0f,       0.64f, 1.0f,  //Top-left
        0.5f, -0.5f, 0.5f,     1.0f, 0.0f, 0.0f,       0.64f, 0.0f,  //Bottom-left
        0.5f, -0.5f, -0.5f,    1.0f, 0.0f, 0.0f,       1.0f, 0.0f,  //Bottom-right

        //Back face
        0.5f, 0.5f, -0.5f,     0.0f, 0.0f, -1.0f,      0.0f, 1.0f,  //Top-left
        -0.5f, 0.5f, -0.5f,    0.0f, 0.0f, -1.0f,      0.64f, 1.0f,  //Top-right
        -0.5f, -0.5f, -0.5f,   0.0f, 0.0f, -1.0f,      0.64f, 0.0f,  //Bottom-right
        0.5f, 0.5f, -0.5f,     0.0f, 0.0f, -1.0f,      0.0f, 1.0f,  //Top-left
        0.5f, -0.5f, -0.5f,    0.0f, 0.0f, -1.0f,      0.0f, 0.0f,  //Bottom-left
        -0.5f, -0.5f, -0.5f,   0.0f, 0.0f, -1.0f,      0.64f, 0.0f,  //Bottom-right

        //Left face
        -0.5f, 0.5f, -0.5f,    -1.0f, 0.0f, 0.0f,      0.64f, 1.0f,  //Top-left
        -0.5f, 0.5f, 0.5f,     -1.0f, 0.0f, 0.0f,      1.0f, 1.0f,  //Top-right
        -0.5f, -0.5f, 0.5f,    -1.0f, 0.0f, 0.0f,      1.0f, 0.0f,  //Bottom-right
        -0.5f, 0.5f, -0.5f,    -1.0f, 0.0f, 0.0f,      0.64f, 1.0f,  //Top-left
        -0.5f, -0.5f, -0.5f,   -1.0f, 0.0f, 0.0f,      0.64f, 0.0f,  //Bottom-left
        -0.5f, -0.5f, 0.5f,    -1.0f, 0.0f, 0.0f,      1.0f, 0.0f,  //Bottom-right
    };

    //Actually create the mesh object from the defined vertices and assign to GLMesh object.
    UCreateMesh(vertices, sizeof(vertices), mesh);  //NOTE: Must pass in size of arrays.
}

//Create pyramid mesh of predefined base width 1, base depth 1, and height 1, and assign to the passed-in GLMesh object.
void UCreatePyramidMesh(GLMesh& mesh)
{
    //First, define Normalized Device Coordinates (xyz), normals (xyz), and texture coordinates (uv) for triangle vertices.
    GLfloat vertices[] =
    {
        //THEORETICALLY, THESE NORMALS DO NOT HAVE TO BE NORMALIZED

        //Bottom face
        -0.5f, -0.5f, 0.5f,   0.0f, -1.0f, 0.0f,       0.0f, 0.0f,
        0.5f, -0.5f, 0.5f,    0.0f, -1.0f, 0.0f,       1.0f, 0.0f,
        0.5f, -0.5f, -0.5f,   0.0f, -1.0f, 0.0f,       1.0f, 1.0f,
        -0.5f, -0.5f, 0.5f,   0.0f, -1.0f, 0.0f,       0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, -1.0f, 0.0f,       0.0f, 1.0f,
        0.5f, -0.5f, -0.5f,   0.0f, -1.0f, 0.0f,       1.0f, 1.0f,

        //Front face
        -0.5f, -0.5f, 0.5f,   0.0f, 0.576f, 0.817f,    0.0f, 0.0f,
        0.5f, -0.5f, 0.5f,    0.0f, 0.576f, 0.817f,    1.0f, 0.0f,
        0.0f, 0.5f, 0.0f,     0.0f, 0.576f, 0.817f,    0.5f, 1.0f,

        //Right face
        0.5f, -0.5f, 0.5f,    0.817f, 0.576f, 0.0f,    0.0f, 0.0f,
        0.5f, -0.5f, -0.5f,   0.817f, 0.576f, 0.0f,    1.0f, 0.0f,
        0.0f, 0.5f, 0.0f,     0.817f, 0.576f, 0.0f,    0.5f, 1.0f,

        //Back face
        0.5f, -0.5f, -0.5f,   0.0f, 0.576f, -0.817f,   0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 0.576f, -0.817f,   1.0f, 0.0f,
        0.0f, 0.5f, 0.0f,     0.0f, 0.576f, -0.817f,   0.5f, 1.0f,

        //Left face
        -0.5f, -0.5f, -0.5f,  -0.817f, 0.576f, 0.0f,   0.0f, 0.0f,
        -0.5f, -0.5f, 0.5f,   -0.817f, 0.576f, 0.0f,   1.0f, 0.0f,
        0.0f, 0.5f, 0.0f,     -0.817f, 0.576f, 0.0f,   0.5f, 1.0f
    };

    //Actually create the mesh object from the defined vertices and assign to GLMesh object.
    UCreateMesh(vertices, sizeof(vertices), mesh);  //NOTE: Must pass in size of array.
}

//Create cylinder mesh of the specified radius (r), height (h), and resolution (rs), and assign to the passed-in GLMesh object.
void UCreateCylinderMesh(float r, float h, float res, GLMesh& mesh)
{
    //Number of vertices needed is 2 * resolution, calculated using a loop.
    //See https://faun.pub/draw-circle-in-opengl-c-2da8d9c2c103 for explanation.

    std::vector<GLfloat> vertices;
    float angle = 360.0f / res;         //Angle effectively pointing to each vertex in the circle

    //Loop through all resolution (res) vertices, adding corresponding position, normal, and UVs to vertices array.
    for (int i = 0; i < res; i++)
    {
        //TOP CIRCLE
        //Add origin point (1, 0, 0) to vertices, is the top circle so uses height/2.
        vertices.push_back(r * 1.0f);
        vertices.push_back(h / 2);
        vertices.push_back(0.0f);
        //Push back normal (top circle points up).
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        vertices.push_back(0.0f);
        //Just use top left corner for UV here.
        vertices.push_back(0.0f);
        vertices.push_back(1.0f);
        //For each res vertex, must add the vertices at 1 and 2 places further to create the circle (see link above).
        for (int j = 1; j < 3; j++)
        {
            //Calculate x and y values of each point based on the cos and sin values of the angle * the radius.
            float currAngle = angle * (i + j);
            float x = r * cos(glm::radians(currAngle));
            float z = r * sin(glm::radians(currAngle));

            //Add point to vertices, is the top circle so uses height/2.
            vertices.push_back(x);
            vertices.push_back(h / 2);
            vertices.push_back(z);
            //Push back normal (top circle points up).
            vertices.push_back(0.0f);
            vertices.push_back(1.0f);
            vertices.push_back(0.0f);
            //UVs here are ugly because of the way the triangles are organized (are not based on center point).
            vertices.push_back((angle * i) / 360.0f);
            vertices.push_back(1.0f);   //Top circle
        }

        //BOTTOM CIRCLE
        //Add origin point (1, 0, 0) to vertices, is the bottom circle so uses -height/2.
        vertices.push_back(r * 1.0f);
        vertices.push_back(-h / 2);
        vertices.push_back(0.0f);
        //Push back normal (bottom circle points down).
        vertices.push_back(0.0f);
        vertices.push_back(-1.0f);
        vertices.push_back(0.0f);
        //Just use bottom left corner for UV here.
        vertices.push_back(0.0f);
        vertices.push_back(0.0f);
        //For each res vertex, must add the vertices at 1 and 2 places further to create the circle (see link above).
        for (int j = 1; j < 3; j++)
        {
            //Calculate x and y values of each point based on the cos and sin values of the angle TIMES the radius.
            float currAngle = angle * (i + j);
            float x = r * cos(glm::radians(currAngle));
            float z = r * sin(glm::radians(currAngle));

            //Add  point to vertices, is the bottom circle so uses -height/2.
            vertices.push_back(x);
            vertices.push_back(-h / 2);
            vertices.push_back(z);
            //Push back normal (bottom circle points down).
            vertices.push_back(0.0f);
            vertices.push_back(-1.0f);
            vertices.push_back(0.0f);
            //UVs here are ugly because of the way the triangles are organized (are not based on center point). 
            vertices.push_back((angle * i) / 360.0f);
            vertices.push_back(0.0f);   //Bottom circle
        }

        //SIDES (I literally accidentally stumbled upon this as a valid solution to the sides issue)
        for (int j = 0; j < 3; j++)
        {
            //Calculate x and y values of each point based on the cos and sin values of the angle TIMES the radius.
            float currAngle = angle * (i + j);
            float x = r * cos(glm::radians(currAngle));
            float z = r * sin(glm::radians(currAngle));

            //Add FIRST point to vertices, is on the top circle so uses height/2.
            vertices.push_back(x);
            vertices.push_back(h / 2);
            vertices.push_back(z);
            //Vertex is a point on a circle, equal distance from the center; vertex has an already-normalized direction.
            vertices.push_back(x);
            vertices.push_back(0.0f);
            vertices.push_back(z);
            //UVs here are ugly because of the way the triangles are organized.
            vertices.push_back((res - i - j) / res);
            vertices.push_back(1.0f);   //Top circle

            //Add SECOND point to vertices, is on the bottom circle so uses -height/2.
            vertices.push_back(x);
            vertices.push_back(-h / 2);
            vertices.push_back(z);
            //Vertex is a point on a circle, equal distance from the center; vertex has an already-normalized direction.
            vertices.push_back(x);
            vertices.push_back(0.0f);
            vertices.push_back(z);
            //UVs here are ugly because of the way the triangles are organized. 
            vertices.push_back((res - i - j) / res);
            vertices.push_back(0.0f);   //Bottom circle
        }
    }

    //Store size of vertices array to be passed into UCreateMesh().
    int vSize = vertices.size() * sizeof(GLfloat);

    //Actually create the mesh object from the defined vertices and assign to GLMesh object.
    UCreateMesh(&vertices[0], vSize, mesh);     //NOTE: Must pass in size of array.
}



//Generates a model matrix from parameters to scale uniformly, rotate on each individual axis, and translate.
glm::mat4 UGenerateModelMatrix(glm::vec3 scale, glm::vec3 rotation, glm::vec3 translate)
{
    //Scale UNIFORMLY by 'scale' parameter.
    glm::mat4 scaleMat = glm::scale(scale);

    //Rotate on EACH AXIS by corresponding parameter values.
    glm::mat4 rotationMat;
    rotationMat = glm::rotate(glm::radians(rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));   //x-axis rotation
    rotationMat *= glm::rotate(glm::radians(rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));  //y-axis
    rotationMat *= glm::rotate(glm::radians(rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));  //z-axis

    //Translate according to vector3 parameter.
    glm::mat4 translMat = glm::translate(translate);

    //Finally, combine all individual transformations to a single model matrix (R to L), then return.
    glm::mat4 model = translMat * rotationMat * scaleMat;
    return model;
}